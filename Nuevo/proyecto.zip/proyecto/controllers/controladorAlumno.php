<?php

include_once("../models/classAlumno.php");

if(isset($_REQUEST["btnAgregar"])) {
    header("location:../views/addAlumno.php");
}elseif(isset($_REQUEST["btnActualizar"])) {
    header("location:../views/addAlumno1.php");
}elseif(isset($_REQUEST["btnModificar"])) {
    header("location:../views/addAlumno2.php");
}elseif(isset($_REQUEST["botonBorra"])){
    $nuevoAprendiz = new Aprendiz ();
   
    print($nuevoAprendiz -> borrarAprendiz("1", "o aprendiz"));
    
}elseif(isset($_REQUEST["botonActu"])) {
    
    $nuevoAprendiz = new Aprendiz();
   
    print($nuevoAprendiz-> actualizarAprendiz("se", "encuentra", "en el", "programa", "ADSO")); 
}elseif(isset($_REQUEST["actAprendiz"])){
    $nombre = $_REQUEST["nombre"];
    $programa = $_REQUEST["programa"];
    $correo = $_REQUEST["correo"];

    $nuevoAprendiz = new Aprendiz();
    print($nuevoAprendiz -> crearAlum($nombre,$programa,$correo));

}elseif(isset($_REQUEST["actAprendiz1"])){
    $nombre = $_REQUEST["nombre"];
    $programa = $_REQUEST["programa"];
    $correo = $_REQUEST["correo"];

    $nuevoAprendiz = new Aprendiz();
    print($nuevoAprendiz -> crearAlum1($nombre,$programa,$correo));

}elseif(isset($_REQUEST["actAprendiz2"])){
    $nombre = $_REQUEST["nombre"];
    $programa = $_REQUEST["programa"];
    $correo = $_REQUEST["correo"];

    $nuevoAprendiz = new Aprendiz();
    print($nuevoAprendiz -> crearAlum2($nombre,$programa,$correo));

}
?>