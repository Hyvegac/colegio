<?php

 include_once("../models/classCoordinador.php");
if(isset($_REQUEST["btnAgregar"])) {
    header("location:../views/addCoord.php");
}elseif(isset($_REQUEST["btnActualizar"])) {
    header("location:../views/addCoord1.php");
}elseif(isset($_REQUEST["btnModificar"])) {
    header("location:../views/addCoord2.php");
}elseif(isset($_REQUEST["btnAgregar"])) {
    $nuevoCoordinador = new Coordinador();
    $nuevoCoordinador-> nombre = "El Coordinador ha sido agregado";
    print($nuevoCoordinador-> nombre ); 
}elseif(isset($_REQUEST["btnCoordinador1"])){
    $nuevoCoordinador = new Coordinador();
   
    print($nuevoCoordinador -> borrarCoordinador("1", "Carlos"));
    
    
}elseif(isset($_REQUEST["btnCoordinador2"])) {
    
    $nuevoCoordinador = new Coordinador();
   
    print($nuevoCoordinador-> actualizarCoordinador("2332489","Carlos ", "Gustino", "GustinoCarlo@gmail.com")); 
}elseif(isset($_REQUEST["actCoord"])){
    $nombre = $_REQUEST["nombre"];
    $programa = $_REQUEST["programa"];
    $correo = $_REQUEST["correo"];

    $nuevoCoordinador = new Coordinador();
    print($nuevoCoordinador -> crearCoord($nombre,$programa,$correo));

}elseif(isset($_REQUEST["actCoord1"])){
    $nombre = $_REQUEST["nombre"];
    $programa = $_REQUEST["programa"];
    $correo = $_REQUEST["correo"];

    $nuevoCoordinador = new Coordinador();
    print($nuevoCoordinador -> crearCoord1($nombre,$programa,$correo));

}elseif(isset($_REQUEST["actCoord2"])){
    $nombre = $_REQUEST["nombre"];
    $programa = $_REQUEST["programa"];
    $correo = $_REQUEST["correo"];

    $nuevoCoordinador = new Coordinador();
    print($nuevoCoordinador -> crearCoord2($nombre,$programa,$correo));

}
?>