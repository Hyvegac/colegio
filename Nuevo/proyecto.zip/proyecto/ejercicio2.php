<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="animacion.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<?php
    print("
    <body>
    <ul class='nav nav-pills'>
      <li class='nav-item'>
        <a class='nav-link active' aria-current='page' href='../ejercicio2.php'>INICIO</a>
      </li>
      <li class='nav-item'>
      <a class='nav-link' href='views/viewAlumno.php'>Alumno</a>
      </li>
      <li class='nav-item'>
      <a class='nav-link' href='views/viewCoordinador.php'>Coordinador</a>
      </li>
      <li class='nav-item'>
        <a class='nav-link' href='views/viewNovedad.php'>Novedades</a>
      </li>
    </ul>
    <div class='header'>
    </div>
    </body>
    ")
    
?> 
</html>