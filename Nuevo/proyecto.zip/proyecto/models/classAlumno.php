<?php

class Aprendiz {
    public $nombre;
    public $apellido;
    public $correo;
    public $telefono;
    public $programa;


    public function borrarAprendiz($idAprendiz, $nombre) {
        print("<h2 style='text-aling: center; color:blue'>El alumno $idAprendiz ha sido borrado</h2> <br/>");
        print("<a href='../views/viewAlumno.php'>Regresar</a>");
    }

    public function actualizarAprendiz($idAprendiz, $nombre, $apellido, $correo) {
        print("<h2 style='text-aling: center; color:blue'>El alumno #1 $idAprendiz  ha sido guardado</h2> <br/>");
        print("<a href='../views/viewAlumno.php'>Regresar</a>");
    }
    public function crearAlum($nombre,$programa,$correo) {
        print("<h2 style='text-aling: center; color:blue'>El alumno: $nombre del programa: $programa con correo: $correo ha sido creado</h2> <br/>");
        print("<a href='../views/viewAlumno.php'>Regresar</a>");
    }
    public function crearAlum1($nombre,$programa,$correo) {
        print("<h2 style='text-aling: center; color:blue'>El alumno: $nombre del programa: $programa con correo: $correo ha sido modificado</h2> <br/>");
        print("<a href='../views/viewAlumno.php'>Regresar</a>");
    }     
    public function crearAlum2($nombre,$programa,$correo) {
        print("<h2 style='text-aling: center; color:blue'>El alumno: $nombre del programa: $programa con correo: $correo ha sido actualizado</h2> <br/>");
        print("<a href='../views/viewAlumno.php'>Regresar</a>");
    }      
};


?>