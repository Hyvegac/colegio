<?php

class Coordinador {
    public $nombre;
    public $apellido;
    public $correo;
    public $programa;


    public function borrarCoordinador($idCoordinador, $nombre) {
        print("<h2 style='text-aling: center; color:blue'>El Coordinador #  $idCoordinador $nombre ha sido borrado</h2> <br/>");
        print("<a href='../views/viewCoordinador.php'>Regresar</a>");
    }

    public function actualizarCoordinador($idCoordinador, $nombre, $apellido, $correo) {
        print("<h2 style='text-aling: center; color:blue'>El Coordinador # $idCoordinador $nombre $apellido $correo ha sido guardado</h2> <br/>");
        print("<a href='../views/viewCoordinador.php'>Regresar</a>");
    }
    public function crearCoord($nombre,$programa,$correo) {
        print("<h2 style='text-aling: center; color:blue'>El Coordinador: $nombre del programa: $programa con correo: $correo ha sido creado</h2> <br/>");
        print("<a href='../views/viewCoordinador.php'>Regresar</a>");
    }
    public function crearCoord1($nombre,$programa,$correo) {
        print("<h2 style='text-aling: center; color:blue'>El Coordinador: $nombre del programa: $programa con correo: $correo ha sido modificado</h2> <br/>");
        print("<a href='../views/viewCoordinador.php'>Regresar</a>");
    }     
    public function crearCoord2($nombre,$programa,$correo) {
        print("<h2 style='text-aling: center; color:blue'>El Coordinador: $nombre del programa: $programa con correo: $correo ha sido actualizado</h2> <br/>");
        print("<a href='../views/viewCoordinador.php'>Regresar</a>");
    }    
}

?>