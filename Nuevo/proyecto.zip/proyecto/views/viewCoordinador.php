<html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css'>
        <link rel='stylesheet' href='https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css'>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function () {
            $('#example').DataTable();
            });
        </script>
    </head>
<?php
	print ("
    <br>
    <form action='../controllers/controladorCoordinador.php' method='POST'>
    <td>
        <input type='submit' id='btnModificar' name='btnModificar' value='Actualizar'/>
        <input type='submit' id='btnAgregar' name='btnAgregar' value='Crear'/>
        <input type='submit' id='btnActualizar' name='btnActualizar' value='Modificar'/>
    </td>
    </form>
    <body>
    <table id='example' class='table table-striped' style='width:100%'>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo</th>
                <th>Telefono</th>
                <th>Profesion</th>
                <th>Actualizar</th>
                <th>Borrar</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Carlos</td>
                <td>Justino</td>
                <td>CarlosJus@gmail.com</td>
                <td>3045213467</td>
                <td>Coordinador</td>
                <td>
                    <form action='../controllers/controladorCoordinador.php' method='POST'>
                    <input type='submit' id='btnCoodinador1' name='btnCoordinador1' value='Guardar'/>
                </td>
                <td>
                    <input type='submit' id='btnCoordinador2' name='btnCoordinador2' value='Eliminar'/>
                </td>
                </form>
                </tr>
            </tbody>
            <tfoot>
            <tr>
                <th>Name</th>
                <th>Surname</th>
                <th>Email</th>
                <th>Program</th>
                <th>Phone</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </tfoot>
   </table>
   <li class='nav-item'>
    <a class='nav-link' href='../ejercicio2.php'>Regresar</a>
   </li>
");
?>
</html>

